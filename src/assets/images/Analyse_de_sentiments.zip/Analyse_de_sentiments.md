# Analyse de besoins avec BERT

**Présentateur** :

TIMITE Abdoul - EQUADE

## Contexte

Le **CFPB** (Consumer Financial Protection Bureau) est une agence gouvernementale américaine qui a pour but de protéger les consommateurs des pratiques déloyales dont ils peuvent être victime de la part des institutions financières.

Chaque semaine, le **CFPB** recolte des centaines de réclamations et les envoie aux entreprises financières concernées afin d'obtenir une réponse pour les consommateurs. Ces réclamations viennent alimenter l'historique des réclamations et cette base de données (**Consumer Complaint Database**) est gérée et mise à dipsosition par le Bureau via son site internet.

Nous voulons, à partir d'un echantillon de cette base de données, prédire le problème associé à une réclamation à partir de sa description en utilisant le modèle BERT. L'objectif est de fournir un outil capable d'identifier rapidement et précisément les problèmes, améliorant ainsi la réactivité et la qualité du service client.

## Démarche

**Déroulé du projet**

1. Manipulation des données
* Importation
* Exploration
* Prétraitement


2. Analyse de sentiment

3. Classification avec BERT


**Les variables à considérer dans la base :**

Consumer complaint narrative = entrée

Issue = etiquette

## Mise en oeuvre


```python
!pip install sentence_transformers
!pip install gensim
!pip install gdown
```

    Requirement already satisfied: sentence_transformers in /usr/local/lib/python3.12/dist-packages (5.2.2)
    Requirement already satisfied: transformers<6.0.0,>=4.41.0 in /usr/local/lib/python3.12/dist-packages (from sentence_transformers) (5.0.0)
    Requirement already satisfied: huggingface-hub>=0.20.0 in /usr/local/lib/python3.12/dist-packages (from sentence_transformers) (1.3.7)
    Requirement already satisfied: torch>=1.11.0 in /usr/local/lib/python3.12/dist-packages (from sentence_transformers) (2.9.0+cu126)
    Requirement already satisfied: numpy in /usr/local/lib/python3.12/dist-packages (from sentence_transformers) (2.0.2)
    Requirement already satisfied: scikit-learn in /usr/local/lib/python3.12/dist-packages (from sentence_transformers) (1.6.1)
    Requirement already satisfied: scipy in /usr/local/lib/python3.12/dist-packages (from sentence_transformers) (1.16.3)
    Requirement already satisfied: typing_extensions>=4.5.0 in /usr/local/lib/python3.12/dist-packages (from sentence_transformers) (4.15.0)
    Requirement already satisfied: tqdm in /usr/local/lib/python3.12/dist-packages (from sentence_transformers) (4.67.2)
    Requirement already satisfied: filelock in /usr/local/lib/python3.12/dist-packages (from huggingface-hub>=0.20.0->sentence_transformers) (3.20.3)
    Requirement already satisfied: fsspec>=2023.5.0 in /usr/local/lib/python3.12/dist-packages (from huggingface-hub>=0.20.0->sentence_transformers) (2025.3.0)
    Requirement already satisfied: hf-xet<2.0.0,>=1.2.0 in /usr/local/lib/python3.12/dist-packages (from huggingface-hub>=0.20.0->sentence_transformers) (1.2.0)
    Requirement already satisfied: httpx<1,>=0.23.0 in /usr/local/lib/python3.12/dist-packages (from huggingface-hub>=0.20.0->sentence_transformers) (0.28.1)
    Requirement already satisfied: packaging>=20.9 in /usr/local/lib/python3.12/dist-packages (from huggingface-hub>=0.20.0->sentence_transformers) (26.0)
    Requirement already satisfied: pyyaml>=5.1 in /usr/local/lib/python3.12/dist-packages (from huggingface-hub>=0.20.0->sentence_transformers) (6.0.3)
    Requirement already satisfied: shellingham in /usr/local/lib/python3.12/dist-packages (from huggingface-hub>=0.20.0->sentence_transformers) (1.5.4)
    Requirement already satisfied: typer-slim in /usr/local/lib/python3.12/dist-packages (from huggingface-hub>=0.20.0->sentence_transformers) (0.21.1)
    Requirement already satisfied: setuptools in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (75.2.0)
    Requirement already satisfied: sympy>=1.13.3 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (1.14.0)
    Requirement already satisfied: networkx>=2.5.1 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (3.6.1)
    Requirement already satisfied: jinja2 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (3.1.6)
    Requirement already satisfied: nvidia-cuda-nvrtc-cu12==12.6.77 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (12.6.77)
    Requirement already satisfied: nvidia-cuda-runtime-cu12==12.6.77 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (12.6.77)
    Requirement already satisfied: nvidia-cuda-cupti-cu12==12.6.80 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (12.6.80)
    Requirement already satisfied: nvidia-cudnn-cu12==9.10.2.21 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (9.10.2.21)
    Requirement already satisfied: nvidia-cublas-cu12==12.6.4.1 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (12.6.4.1)
    Requirement already satisfied: nvidia-cufft-cu12==11.3.0.4 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (11.3.0.4)
    Requirement already satisfied: nvidia-curand-cu12==10.3.7.77 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (10.3.7.77)
    Requirement already satisfied: nvidia-cusolver-cu12==11.7.1.2 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (11.7.1.2)
    Requirement already satisfied: nvidia-cusparse-cu12==12.5.4.2 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (12.5.4.2)
    Requirement already satisfied: nvidia-cusparselt-cu12==0.7.1 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (0.7.1)
    Requirement already satisfied: nvidia-nccl-cu12==2.27.5 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (2.27.5)
    Requirement already satisfied: nvidia-nvshmem-cu12==3.3.20 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (3.3.20)
    Requirement already satisfied: nvidia-nvtx-cu12==12.6.77 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (12.6.77)
    Requirement already satisfied: nvidia-nvjitlink-cu12==12.6.85 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (12.6.85)
    Requirement already satisfied: nvidia-cufile-cu12==1.11.1.6 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (1.11.1.6)
    Requirement already satisfied: triton==3.5.0 in /usr/local/lib/python3.12/dist-packages (from torch>=1.11.0->sentence_transformers) (3.5.0)
    Requirement already satisfied: regex!=2019.12.17 in /usr/local/lib/python3.12/dist-packages (from transformers<6.0.0,>=4.41.0->sentence_transformers) (2025.11.3)
    Requirement already satisfied: tokenizers<=0.23.0,>=0.22.0 in /usr/local/lib/python3.12/dist-packages (from transformers<6.0.0,>=4.41.0->sentence_transformers) (0.22.2)
    Requirement already satisfied: safetensors>=0.4.3 in /usr/local/lib/python3.12/dist-packages (from transformers<6.0.0,>=4.41.0->sentence_transformers) (0.7.0)
    Requirement already satisfied: joblib>=1.2.0 in /usr/local/lib/python3.12/dist-packages (from scikit-learn->sentence_transformers) (1.5.3)
    Requirement already satisfied: threadpoolctl>=3.1.0 in /usr/local/lib/python3.12/dist-packages (from scikit-learn->sentence_transformers) (3.6.0)
    Requirement already satisfied: anyio in /usr/local/lib/python3.12/dist-packages (from httpx<1,>=0.23.0->huggingface-hub>=0.20.0->sentence_transformers) (4.12.1)
    Requirement already satisfied: certifi in /usr/local/lib/python3.12/dist-packages (from httpx<1,>=0.23.0->huggingface-hub>=0.20.0->sentence_transformers) (2026.1.4)
    Requirement already satisfied: httpcore==1.* in /usr/local/lib/python3.12/dist-packages (from httpx<1,>=0.23.0->huggingface-hub>=0.20.0->sentence_transformers) (1.0.9)
    Requirement already satisfied: idna in /usr/local/lib/python3.12/dist-packages (from httpx<1,>=0.23.0->huggingface-hub>=0.20.0->sentence_transformers) (3.11)
    Requirement already satisfied: h11>=0.16 in /usr/local/lib/python3.12/dist-packages (from httpcore==1.*->httpx<1,>=0.23.0->huggingface-hub>=0.20.0->sentence_transformers) (0.16.0)
    Requirement already satisfied: mpmath<1.4,>=1.1.0 in /usr/local/lib/python3.12/dist-packages (from sympy>=1.13.3->torch>=1.11.0->sentence_transformers) (1.3.0)
    Requirement already satisfied: MarkupSafe>=2.0 in /usr/local/lib/python3.12/dist-packages (from jinja2->torch>=1.11.0->sentence_transformers) (3.0.3)
    Requirement already satisfied: click>=8.0.0 in /usr/local/lib/python3.12/dist-packages (from typer-slim->huggingface-hub>=0.20.0->sentence_transformers) (8.3.1)
    Collecting gensim
      Downloading gensim-4.4.0-cp312-cp312-manylinux_2_24_x86_64.manylinux_2_28_x86_64.whl.metadata (8.4 kB)
    Requirement already satisfied: numpy>=1.18.5 in /usr/local/lib/python3.12/dist-packages (from gensim) (2.0.2)
    Requirement already satisfied: scipy>=1.7.0 in /usr/local/lib/python3.12/dist-packages (from gensim) (1.16.3)
    Requirement already satisfied: smart_open>=1.8.1 in /usr/local/lib/python3.12/dist-packages (from gensim) (7.5.0)
    Requirement already satisfied: wrapt in /usr/local/lib/python3.12/dist-packages (from smart_open>=1.8.1->gensim) (2.1.0)
    Downloading gensim-4.4.0-cp312-cp312-manylinux_2_24_x86_64.manylinux_2_28_x86_64.whl (27.9 MB)
    [2K   [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m27.9/27.9 MB[0m [31m26.3 MB/s[0m eta [36m0:00:00[0m
    [?25hInstalling collected packages: gensim
    Successfully installed gensim-4.4.0
    


```python
import transformers
import torch
from transformers import BertModel, BertTokenizer, get_linear_schedule_with_warmup, BertForSequenceClassification
from torch.optim import AdamW
from torch.utils.data import DataLoader, TensorDataset, random_split, Dataset
from torch.optim import AdamW
import numpy as np
import pandas as pd
import gdown
import seaborn as sns
from pylab import rcParams
import matplotlib.pyplot as plt
from matplotlib import rc
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from collections import defaultdict
from textwrap import wrap
from torch import nn, optim
import pandas as pd
import numpy as np
from scipy import spatial
import os
import matplotlib
import matplotlib.pyplot as plt
import spacy
from spacy.lang.en import English
import en_core_web_sm
import multiprocessing
import gensim
from gensim.models import Word2Vec
from sklearn.manifold import TSNE
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.cluster import contingency_matrix
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from mlxtend.plotting import plot_confusion_matrix
import plotly.express as px
import plotly.graph_objects as go
import re
from sentence_transformers import SentenceTransformer
```

### 1. Manipulation des données

Nous passons par Google Drive pour importer la base de données.


```python
file_id = "1mqaJzAeyhxPF6YRzP6oNIPI3YcK-nZSP"
url = f"https://drive.google.com/uc?id={file_id}"

gdown.download(url, "base_reclamations.csv", quiet=False)

```

    Downloading...
    From (original): https://drive.google.com/uc?id=1mqaJzAeyhxPF6YRzP6oNIPI3YcK-nZSP
    From (redirected): https://drive.google.com/uc?id=1mqaJzAeyhxPF6YRzP6oNIPI3YcK-nZSP&confirm=t&uuid=7806da24-fb53-43cd-aa13-bb4d68198506
    To: /content/base_reclamations.csv
    100%|██████████| 117M/117M [00:00<00:00, 203MB/s]
    




    'base_reclamations.csv'




```python
# Importation de la base de données
reclamations = pd.read_csv("base_reclamations.csv")
reclamations.head(10)
```





  <div id="df-e6988016-d26c-40e2-8a25-64b7d1ad51b1" class="colab-df-container">
    <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date received</th>
      <th>Product</th>
      <th>Sub-product</th>
      <th>Issue</th>
      <th>Sub-issue</th>
      <th>Consumer complaint narrative</th>
      <th>Company public response</th>
      <th>Company</th>
      <th>State</th>
      <th>ZIP code</th>
      <th>Tags</th>
      <th>Consumer consent provided?</th>
      <th>Submitted via</th>
      <th>Date sent to company</th>
      <th>Company response to consumer</th>
      <th>Timely response?</th>
      <th>Consumer disputed?</th>
      <th>Complaint ID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01/13/23</td>
      <td>Credit reporting, credit repair services, or o...</td>
      <td>Credit reporting</td>
      <td>Incorrect information on your report</td>
      <td>Information belongs to someone else</td>
      <td>Right now I am bothered! I have attempted to b...</td>
      <td>NaN</td>
      <td>EQUIFAX, INC.</td>
      <td>TX</td>
      <td>78750</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>01/13/23</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>6439929</td>
    </tr>
    <tr>
      <th>1</th>
      <td>08/23/23</td>
      <td>Credit reporting, credit repair services, or o...</td>
      <td>Credit reporting</td>
      <td>Problem with a credit reporting company's inve...</td>
      <td>Investigation took more than 30 days</td>
      <td>Online disputes were filed with all 3 credit b...</td>
      <td>Company has responded to the consumer and the ...</td>
      <td>Experian Information Solutions Inc.</td>
      <td>TX</td>
      <td>75217</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>08/23/23</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>7438064</td>
    </tr>
    <tr>
      <th>2</th>
      <td>09/23/23</td>
      <td>Credit reporting or other personal consumer re...</td>
      <td>Credit reporting</td>
      <td>Incorrect information on your report</td>
      <td>Information belongs to someone else</td>
      <td>This is my NUMEROUS request that I have been a...</td>
      <td>Company has responded to the consumer and the ...</td>
      <td>Experian Information Solutions Inc.</td>
      <td>TX</td>
      <td>77082</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>09/23/23</td>
      <td>Closed with non-monetary relief</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>7590175</td>
    </tr>
    <tr>
      <th>3</th>
      <td>06/25/23</td>
      <td>Credit reporting, credit repair services, or o...</td>
      <td>Credit reporting</td>
      <td>Improper use of your report</td>
      <td>Reporting company used your report improperly</td>
      <td>In accordance with Fair Credit Reporting Act t...</td>
      <td>NaN</td>
      <td>National Credit Adjusters, LLC</td>
      <td>TX</td>
      <td>XXXXX</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>06/25/23</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>7164323</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01/23/23</td>
      <td>Checking or savings account</td>
      <td>Checking account</td>
      <td>Closing an account</td>
      <td>Funds not received from closed account</td>
      <td>Capital One sent my payment to a closed acct. ...</td>
      <td>NaN</td>
      <td>CAPITAL ONE FINANCIAL CORPORATION</td>
      <td>TX</td>
      <td>77070</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>01/24/23</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>6474699</td>
    </tr>
    <tr>
      <th>5</th>
      <td>01/24/23</td>
      <td>Checking or savings account</td>
      <td>Checking account</td>
      <td>Problem caused by your funds being low</td>
      <td>Overdrafts and overdraft fees</td>
      <td>When my account had enough funds I would get w...</td>
      <td>Company has responded to the consumer and the ...</td>
      <td>WELLS FARGO &amp; COMPANY</td>
      <td>TX</td>
      <td>77494</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>01/24/23</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>6474563</td>
    </tr>
    <tr>
      <th>6</th>
      <td>09/18/23</td>
      <td>Credit reporting or other personal consumer re...</td>
      <td>Credit reporting</td>
      <td>Problem with a company's investigation into an...</td>
      <td>Their investigation did not fix an error on yo...</td>
      <td>The existence of a derogatory rating on my acc...</td>
      <td>NaN</td>
      <td>JPMORGAN CHASE &amp; CO.</td>
      <td>TX</td>
      <td>77379</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>09/18/23</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>7568480</td>
    </tr>
    <tr>
      <th>7</th>
      <td>09/26/23</td>
      <td>Credit reporting or other personal consumer re...</td>
      <td>Credit reporting</td>
      <td>Improper use of your report</td>
      <td>Reporting company used your report improperly</td>
      <td>15 U.S. Code 6802 - Obligations with respect t...</td>
      <td>NaN</td>
      <td>EQUIFAX, INC.</td>
      <td>TX</td>
      <td>XXXXX</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>09/26/23</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>7601151</td>
    </tr>
    <tr>
      <th>8</th>
      <td>12/12/23</td>
      <td>Credit reporting or other personal consumer re...</td>
      <td>Credit reporting</td>
      <td>Problem with a company's investigation into an...</td>
      <td>Was not notified of investigation status or re...</td>
      <td>On XX/XX/23, I submitted disputes to XXXX, Equ...</td>
      <td>NaN</td>
      <td>EQUIFAX, INC.</td>
      <td>TX</td>
      <td>75052</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>12/12/23</td>
      <td>Closed with non-monetary relief</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>7987938</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10/03/22</td>
      <td>Credit reporting, credit repair services, or o...</td>
      <td>Credit reporting</td>
      <td>Improper use of your report</td>
      <td>Reporting company used your report improperly</td>
      <td>In accordance with the Fair Credit Reporting a...</td>
      <td>Company has responded to the consumer and the ...</td>
      <td>Experian Information Solutions Inc.</td>
      <td>TX</td>
      <td>765XX</td>
      <td>NaN</td>
      <td>Consent provided</td>
      <td>Web</td>
      <td>10/03/22</td>
      <td>Closed with non-monetary relief</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>6045965</td>
    </tr>
  </tbody>
</table>
</div>
    <div class="colab-df-buttons">

  <div class="colab-df-container">
    <button class="colab-df-convert" onclick="convertToInteractive('df-e6988016-d26c-40e2-8a25-64b7d1ad51b1')"
            title="Convert this dataframe to an interactive table."
            style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960">
    <path d="M120-120v-720h720v720H120Zm60-500h600v-160H180v160Zm220 220h160v-160H400v160Zm0 220h160v-160H400v160ZM180-400h160v-160H180v160Zm440 0h160v-160H620v160ZM180-180h160v-160H180v160Zm440 0h160v-160H620v160Z"/>
  </svg>
    </button>

  <style>
    .colab-df-container {
      display:flex;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    .colab-df-buttons div {
      margin-bottom: 4px;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

    <script>
      const buttonEl =
        document.querySelector('#df-e6988016-d26c-40e2-8a25-64b7d1ad51b1 button.colab-df-convert');
      buttonEl.style.display =
        google.colab.kernel.accessAllowed ? 'block' : 'none';

      async function convertToInteractive(key) {
        const element = document.querySelector('#df-e6988016-d26c-40e2-8a25-64b7d1ad51b1');
        const dataTable =
          await google.colab.kernel.invokeFunction('convertToInteractive',
                                                    [key], {});
        if (!dataTable) return;

        const docLinkHtml = 'Like what you see? Visit the ' +
          '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
          + ' to learn more about interactive tables.';
        element.innerHTML = '';
        dataTable['output_type'] = 'display_data';
        await google.colab.output.renderOutput(dataTable, element);
        const docLink = document.createElement('div');
        docLink.innerHTML = docLinkHtml;
        element.appendChild(docLink);
      }
    </script>
  </div>


    </div>
  </div>





```python
# Dimension de la base de données
reclamations.shape
```




    (89793, 18)



Notre base de données est donc composée de 89 793 réclamations et 18 variables décrivant ces réclamations.


```python
reclamations.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 89793 entries, 0 to 89792
    Data columns (total 18 columns):
     #   Column                        Non-Null Count  Dtype  
    ---  ------                        --------------  -----  
     0   Date received                 89793 non-null  object 
     1   Product                       89793 non-null  object 
     2   Sub-product                   89792 non-null  object 
     3   Issue                         89793 non-null  object 
     4   Sub-issue                     85515 non-null  object 
     5   Consumer complaint narrative  89793 non-null  object 
     6   Company public response       51325 non-null  object 
     7   Company                       89793 non-null  object 
     8   State                         89793 non-null  object 
     9   ZIP code                      89793 non-null  object 
     10  Tags                          9324 non-null   object 
     11  Consumer consent provided?    89793 non-null  object 
     12  Submitted via                 89793 non-null  object 
     13  Date sent to company          89793 non-null  object 
     14  Company response to consumer  89792 non-null  object 
     15  Timely response?              89793 non-null  object 
     16  Consumer disputed?            0 non-null      float64
     17  Complaint ID                  89793 non-null  int64  
    dtypes: float64(1), int64(1), object(16)
    memory usage: 12.3+ MB
    

Nous observons que la majorité de nos variables ont des observations complètes, notamment les variables **Consumer complaint narrative** et **Issue** qui nous inttèresse. On peut neanmmoins remmarquer que la variable **Consumer disputed?** n'est pas renseigné.

Les variables étant majoritairement textuelles, elles sont de type *object*.


```python
import matplotlib.pyplot as plt
import missingno as msno
import seaborn as sns

# Valeurs manquantes
msno.matrix(reclamations)
```




    <Axes: >




    
![png](output_17_1.png)
    


Cette représentation nous permet de mieux visualiser l'ampleur des valeurs manquantes, que nous avions déjà identifié plus haut.

Les variables comportant des variables manquantes sont :
* Consumer disputed?, qui n'est pas renseigné
* Tags
* Company public response
* Sub-issue

Il faut savoir qu'il n'est pas courant que les entreprises à qui sont adressées des réclamations envoient des reponses dites publiques (que tout le monde peut connaitre). Le plus souvent les réclamations se règle en privée, d'où le fait que la variable ***Company public response*** comporte beaucoup de valeurs manquantes.


```python
reclamations.nunique()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Date received</th>
      <td>725</td>
    </tr>
    <tr>
      <th>Product</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Sub-product</th>
      <td>55</td>
    </tr>
    <tr>
      <th>Issue</th>
      <td>84</td>
    </tr>
    <tr>
      <th>Sub-issue</th>
      <td>195</td>
    </tr>
    <tr>
      <th>Consumer complaint narrative</th>
      <td>65885</td>
    </tr>
    <tr>
      <th>Company public response</th>
      <td>10</td>
    </tr>
    <tr>
      <th>Company</th>
      <td>1273</td>
    </tr>
    <tr>
      <th>State</th>
      <td>1</td>
    </tr>
    <tr>
      <th>ZIP code</th>
      <td>586</td>
    </tr>
    <tr>
      <th>Tags</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Consumer consent provided?</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Submitted via</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Date sent to company</th>
      <td>742</td>
    </tr>
    <tr>
      <th>Company response to consumer</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Timely response?</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Consumer disputed?</th>
      <td>0</td>
    </tr>
    <tr>
      <th>Complaint ID</th>
      <td>89793</td>
    </tr>
  </tbody>
</table>
</div><br><label><b>dtype:</b> int64</label>



Nous remarquons que plusieurs variables ont des valeurs uniques. Cela n'est cependant pas anormal. En effet, nous avons sélectionner les données récoltées dans l'Etat du **TEXAS**, ce qui fait que la variable ***State*** n'a qu'une valeur unique qui est "**TEXAS**". De même pour les variables sur le consentement et le moyen d'envoi des réclamations (***Consumer consent provided?*** et ***Submitted via***) : ce sont seulement les réclamations envoyées via le site du CPFB, sur lequel le consentement a été donné de les publier, qui figurent dans l'historique des réclamations gérées par le CPFB.


```python
reclamations.duplicated().sum()/len(reclamations)*100
```




    np.float64(0.0)



Notre jeu de données ne comporte pas de ligne dupliquées, ce qui est une bonne nouvelle.


```python
def plot_categorical(data: pd.DataFrame, x: str, n: int):
    """
    Diagramme de comptage pour une variable catégorielle avec Plotly

    Parameters:
    -----------
    data: DataFrame
        La base de données

    x: str
        La variable catégorielle à représenter

    n: int
        Taille de la police pour l'affichage des modalités
    """

    # Compter les occurrences de chaque catégorie
    counts = data[x].value_counts().reset_index()
    counts.columns = [x, 'count']

    # Créer le graphique à barres
    fig = go.Figure(data=[
        go.Bar(x=counts[x], y=counts['count'], marker_color='blue')
    ])

    # Mettre à jour la mise en page
    fig.update_layout(
        xaxis=dict(tickangle=-45),
        font=dict(size=n),
        xaxis_title=x,
        yaxis_title='Count'
    )

    # Afficher le graphique
    fig.show()

#Exemple d'utilisation avec un DataFrame `reclamations` et une colonne catégorielle "Issue"
plot_categorical(reclamations, "Issue", 7)

```


<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>                <div id="85ca3c7f-8fbb-42ad-8403-068deba80189" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("85ca3c7f-8fbb-42ad-8403-068deba80189")) {                    Plotly.newPlot(                        "85ca3c7f-8fbb-42ad-8403-068deba80189",                        [{"marker":{"color":"blue"},"x":["Incorrect information on your report","Improper use of your report","Problem with a credit reporting company's investigation into an existing problem","Problem with a company's investigation into an existing problem","Attempts to collect debt not owed","Managing an account","Written notification about debt","Problem with a purchase shown on your statement","Trouble during payment process","False statements or representation","Took or threatened to take negative or legal action","Fraud or scam","Closing an account","Getting a credit card","Communication tactics","Problem with a lender or other company charging your account","Dealing with your lender or servicer","Struggling to pay mortgage","Unable to get your credit report or credit score","Problem when making payments","Other features, terms, or problems","Opening an account","Managing the loan or lease","Fees or interest","Credit monitoring or identity theft protection services","Problem caused by your funds being low","Applying for a mortgage or refinancing an existing mortgage","Struggling to pay your loan","Problem with fraud alerts or security freezes","Closing your account","Getting a loan or lease","Problems at the end of the loan or lease","Charged fees or interest you didn't expect","Closing on a mortgage","Threatened to contact someone or share information improperly","Other transaction problem","Trouble using your card","Advertising and marketing, including promotional offers","Unauthorized transactions or other transaction problem","Trouble using the card","Managing, opening, or closing your mobile wallet account","Money was not available when promised","Struggling to repay your loan","Problem with a purchase or transfer","Problem with the payoff process at the end of the loan","Unexpected or other fees","Problem with a company's investigation into an existing issue","Getting the loan","Confusing or missing disclosures","Repossession","Problem with customer service","Problem getting a card or closing an account","Getting a line of credit","Confusing or misleading advertising or marketing","Received a loan you didn't apply for","Struggling to pay your bill","Problem with additional add-on products or services","Identity theft protection or other monitoring services","Trouble accessing funds in your mobile or digital wallet","Other service problem","Electronic communications","Can't stop withdrawals from your bank account","Can't contact lender or servicer","Loan payment wasn't credited to your account","Money was taken from your bank account on the wrong day or for the wrong amount","Vehicle was repossessed or sold the vehicle","Lost or stolen check","Was approved for a loan, but didn't receive the money","Wrong amount charged or received","Getting a loan","Didn't provide services promised","Lost or stolen money order","Problem adding money","Credit limit changed","Excessive fees","Problem with cash advance","Vehicle was damaged or destroyed the vehicle","Charged upfront or unexpected fees","Overdraft, savings, or rewards features","Advertising","Problem with overdraft","Unauthorized withdrawals or charges","Issues with repayment","Problems receiving the advance"],"y":[24980,22410,15954,4289,3615,2276,1421,1075,1056,815,717,640,583,547,545,538,503,482,436,416,415,415,383,355,326,304,283,275,267,265,214,202,190,184,174,174,170,170,142,136,114,107,100,99,87,84,71,66,63,59,56,51,43,42,39,36,35,32,29,29,25,22,17,14,14,13,13,12,11,10,9,7,7,7,7,5,5,3,2,2,1,1,1,1],"type":"bar"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"tickangle":-45,"title":{"text":"Issue"}},"font":{"size":7},"yaxis":{"title":{"text":"Count"}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('85ca3c7f-8fbb-42ad-8403-068deba80189');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>


La variable **Issue** comportent plusieurs types de description du problème. Nous remarquons cependant que la majorité des réclamations porte sur un petit nombre de problèmes spécifiques. Regardons les de plus près :


```python
counts = reclamations['Issue'].value_counts()
top_counts = counts[:10]

if len(counts) > 10:
    other_count = counts[10:].sum()
    top_counts['Autres'] = other_count

# Création du graphique à secteurs avec Plotly
fig = go.Figure(data=[go.Pie(labels=top_counts.index, values=top_counts, hole=0.3)])

# Mise à jour de la mise en page du graphique
fig.update_layout(
    title_text='Répartition de la variable Issue',
    annotations=[dict(text='Issue', x=0.5, y=0.5, font_size=20, showarrow=False)]
)

# Affichage du graphique
fig.show()
```


<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>                <div id="7d18ade7-e0bd-430f-bbaa-05ce94f81da0" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("7d18ade7-e0bd-430f-bbaa-05ce94f81da0")) {                    Plotly.newPlot(                        "7d18ade7-e0bd-430f-bbaa-05ce94f81da0",                        [{"hole":0.3,"labels":["Incorrect information on your report","Improper use of your report","Problem with a credit reporting company's investigation into an existing problem","Problem with a company's investigation into an existing problem","Attempts to collect debt not owed","Managing an account","Written notification about debt","Problem with a purchase shown on your statement","Trouble during payment process","False statements or representation","Autres"],"values":[24980,22410,15954,4289,3615,2276,1421,1075,1056,815,11902],"type":"pie"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"title":{"text":"Répartition de la variable Issue"},"annotations":[{"showarrow":false,"text":"Issue","x":0.5,"y":0.5,"font":{"size":20}}]},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('7d18ade7-e0bd-430f-bbaa-05ce94f81da0');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>


On note donc que les principales préoccupations des utilisateurs (***Incorrect information on your report*** et ***Improper use of your report***) dans notre base de données, représentant plus de 50% des cas de réclamation, sont liées aux **credit reports**. C'est un historique de l'état des finances des individus et peut affecter la capacité à obtenir un crédit, un emploi ou une assurance.

Nous avons sélectionné aléatoirement un sous-ensemble de 5000 lignes dans notre ensemble de données initial, qui contient au total 89783 lignes. Cette réduction de taille nous permettra de travailler plus efficacement avec notre ensemble de données tout en conservant une représentation significative de nos données pour nos analyses et nos expériences.


```python
data_reclamations = reclamations.sample(n=5000, random_state=42)
data_reclamations.reset_index(drop=True, inplace=True)
```


```python
# Les variables pertinentes
data_reclamations = data_reclamations[["Consumer complaint narrative","Issue"]]
data_reclamations.head(15)
```





  <div id="df-c231be25-c86f-4393-9eb8-3e7655d79827" class="colab-df-container">
    <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Consumer complaint narrative</th>
      <th>Issue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>In accordance with the Fair Credit Reporting a...</td>
      <td>Improper use of your report</td>
    </tr>
    <tr>
      <th>1</th>
      <td>I believe I have been a victim of fraudulent a...</td>
      <td>Incorrect information on your report</td>
    </tr>
    <tr>
      <th>2</th>
      <td>In accordance with the Fair Credit Reporting a...</td>
      <td>Improper use of your report</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15 USC 1681 Section 602 States I have the righ...</td>
      <td>Improper use of your report</td>
    </tr>
    <tr>
      <th>4</th>
      <td>In accordance with the Fair Credit Reporting A...</td>
      <td>Improper use of your report</td>
    </tr>
    <tr>
      <th>5</th>
      <td>XXXX in the name of Clarity Services is doing ...</td>
      <td>Improper use of your report</td>
    </tr>
    <tr>
      <th>6</th>
      <td>I am XXXX XXXX and Im submitting this complain...</td>
      <td>Problem with fraud alerts or security freezes</td>
    </tr>
    <tr>
      <th>7</th>
      <td>I was contacted by Citibank about 2 months ago...</td>
      <td>Managing an account</td>
    </tr>
    <tr>
      <th>8</th>
      <td>On XX/XX/2022 sent a letter regarding inaccura...</td>
      <td>Problem with a credit reporting company's inve...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>This is my XXXX endeavor to tell you that I am...</td>
      <td>Incorrect information on your report</td>
    </tr>
    <tr>
      <th>10</th>
      <td>I submitted a credit repair request to a compa...</td>
      <td>Problem with a credit reporting company's inve...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>This is my 3rd endeavor to tell you that I am ...</td>
      <td>Incorrect information on your report</td>
    </tr>
    <tr>
      <th>12</th>
      <td>In Accordance with the Fair Credit Reporting A...</td>
      <td>Improper use of your report</td>
    </tr>
    <tr>
      <th>13</th>
      <td>When I reviewed my credit report, I discovered...</td>
      <td>Problem with a credit reporting company's inve...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Kindly delete these unauthorized accounts from...</td>
      <td>Incorrect information on your report</td>
    </tr>
  </tbody>
</table>
</div>
    <div class="colab-df-buttons">

  <div class="colab-df-container">
    <button class="colab-df-convert" onclick="convertToInteractive('df-c231be25-c86f-4393-9eb8-3e7655d79827')"
            title="Convert this dataframe to an interactive table."
            style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960">
    <path d="M120-120v-720h720v720H120Zm60-500h600v-160H180v160Zm220 220h160v-160H400v160Zm0 220h160v-160H400v160ZM180-400h160v-160H180v160Zm440 0h160v-160H620v160ZM180-180h160v-160H180v160Zm440 0h160v-160H620v160Z"/>
  </svg>
    </button>

  <style>
    .colab-df-container {
      display:flex;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    .colab-df-buttons div {
      margin-bottom: 4px;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

    <script>
      const buttonEl =
        document.querySelector('#df-c231be25-c86f-4393-9eb8-3e7655d79827 button.colab-df-convert');
      buttonEl.style.display =
        google.colab.kernel.accessAllowed ? 'block' : 'none';

      async function convertToInteractive(key) {
        const element = document.querySelector('#df-c231be25-c86f-4393-9eb8-3e7655d79827');
        const dataTable =
          await google.colab.kernel.invokeFunction('convertToInteractive',
                                                    [key], {});
        if (!dataTable) return;

        const docLinkHtml = 'Like what you see? Visit the ' +
          '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
          + ' to learn more about interactive tables.';
        element.innerHTML = '';
        dataTable['output_type'] = 'display_data';
        await google.colab.output.renderOutput(dataTable, element);
        const docLink = document.createElement('div');
        docLink.innerHTML = docLinkHtml;
        element.appendChild(docLink);
      }
    </script>
  </div>


    </div>
  </div>




Il est recommandé d'appliquer le nettoyage uniquement sur les variables d'entrées qui seront utilisée pour entrainer notre modèle. Par conséquent nous appliquerons le nettoyage sur les variables ***Consumer complaint narrative***, qui est la description de la réclamation, et ***Issue*** qui est le problème remonté dans la description et que nous utiliserons comme "Label" dans notre modèle.


```python
data_reclamations["Consumer complaint narrative"][3]
```




    '15 USC 1681 Section 602 States I have the right to privacy.\n\n15 USC 1681 Section 604 A Section 2 : It also states a consumer reporting agency can not furnish an account without my written instructions.\n\n15 U.S. Code 1681a - Definitions ; rules of construction - Exclusion.-Except as provided in paragraph the term " consumer report \'\' does not include -- any report containing information solely as to transactions or experience between the consumer and the person making the report ; 15 USC 1666B : A creditor may not treat a payment on a credit card account under an open end consumer credit plan as late for purpose.'



On peut voir que la description comporte plusieurs types de caractères, notamment des caractères spéciaux comme des paranthèses ou des tirets. Certains mots sont aussi en majuscules dans le texte et il y a des espaces supplémentaires entre d'autres mots.

Nous devons donc nettoyer notre base avant de passer à l'entraînement de notre modèle. Cela garantie que le modèle se concentre sur les informations pertinentes, réduit le risque de surapprentissage et améliore généralement les performances.


```python
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Téléchargements NLTK
nltk.download("punkt")
nltk.download("punkt_tab")
nltk.download("stopwords")

STOP_WORDS = set(stopwords.words("english"))

def clean_text(text):
    if not isinstance(text, str):
        return ""

    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()

    tokens = word_tokenize(text, language="english")
    tokens = [t for t in tokens if t not in STOP_WORDS]

    return " ".join(tokens)
```

    [nltk_data] Downloading package punkt to /root/nltk_data...
    [nltk_data]   Package punkt is already up-to-date!
    [nltk_data] Downloading package punkt_tab to /root/nltk_data...
    [nltk_data]   Unzipping tokenizers/punkt_tab.zip.
    [nltk_data] Downloading package stopwords to /root/nltk_data...
    [nltk_data]   Package stopwords is already up-to-date!
    

Nous definissons une fonction **clean_texte** qui nous permet d'effectuer le nettoyage du texte et l'appliquons par la suite à toutes les colonnes de notre base de données.


```python
data_reclamations["Consumer complaint narrative"] = data_reclamations["Consumer complaint narrative"].fillna("").apply(clean_text)

data_reclamations["Consumer complaint narrative"][3]
```




    '15 usc 1681 section 602 states right privacy 15 usc 1681 section 604 section 2 also states consumer reporting agency furnish account without written instructions 15 u code 1681a definitions rules construction exclusion except provided paragraph term consumer report include report containing information solely transactions experience consumer person making report 15 usc 1666b creditor may treat payment credit card account open end consumer credit plan late purpose'



Nous constatons maintenant que la description de la réclamation a été néttoyé des éléments spécifiés dans notre fonction **clean_text**.


```python
# Encoder les labels
data_reclamations['Issue_Category'], uniques = pd.factorize(data_reclamations['Issue'])
category_mapping = {index: label for index, label in enumerate(uniques)}

# Vérifiez le nombre de classes uniques et les étiquettes correspondantes
num_classes = len(np.unique(data_reclamations['Issue_Category']))
target_names = [category_mapping[i] for i in range(num_classes)]
```

Nous encodons la variable ***Issue*** qui nous servira de label. Puis nous vérifions que les catégories correspondent bien aux descriptions.


```python
# Text mining
from nltk.tokenize import word_tokenize
import nltk
import collections

all_desc = ' '.join([text for text in data_reclamations['Consumer complaint narrative']])
len(all_desc)
```




    3443960



Nous allons regarder les mots les plus récurrents dans la description des réclamations. Pour cela, nous regroupons toutes les descriptions ensembles. Cela nous donne un texte de taille 60 407 767.


```python
nltk.download('punkt')
all_desc_1_gram = word_tokenize(all_desc, language="english")
all_desc_common = collections.Counter(all_desc_1_gram).most_common()
all_desc_common[0:30]
```

    [nltk_data] Downloading package punkt to /root/nltk_data...
    [nltk_data]   Package punkt is already up-to-date!
    




    [('xxxx', 97996),
     ('xx', 11195),
     ('credit', 9914),
     ('account', 8425),
     ('consumer', 6810),
     ('information', 6746),
     ('reporting', 6297),
     ('report', 6229),
     ('15', 4891),
     ('section', 4100),
     ('00', 3698),
     ('u', 3578),
     ('c', 3293),
     ('accounts', 2930),
     ('states', 2829),
     ('agency', 2694),
     ('1681', 2663),
     ('2', 2270),
     ('also', 2242),
     ('balance', 2037),
     ('items', 1951),
     ('without', 1935),
     ('xxxxxxxx', 1814),
     ('please', 1798),
     ('inaccurate', 1754),
     ('act', 1750),
     ('debt', 1735),
     ('rights', 1732),
     ('privacy', 1695),
     ('payment', 1653)]



Dans cette liste des 30 premiers mots les plus récurrents, nous retrouvons les mots ***account*** ou ***accounts***, ***balance***, ***agency*** et ***debt*** qui relève du vocabulaire de la banque; ce qui est cohérent avec notre base de données. Nous avons également les mots ***15***, ***usc***, ***section*** et ***1681*** qui font référence au **Fair Credit Reporting Act** qui est une loi permettant aux consommateurs d'accéder à leurs rapports de crédit, de les corriger et de limiter leur utilisation. Enfin, le mot ***inaccurate***, sous entend que les réclamations les plus fréquentes sont liées à des problèmes d'inexactitude dans les rélévés financiers des consommateurs. Ce qui est cohérent avec la répartition de notre variable ***Issue*** vu plus haut.

### 2. Analyse de sentiment

Nous allons faire une analyse le sentiment des descriptions de réclamations en utilisant la fonction `get_sentiment`, puis crée des colonnes distinctes pour stocker la polarité et la subjectivité de chaque texte. Cela permet d'obtenir une vision plus détaillée de la nature des réclamations, en indiquant à quel point elles sont positives, négatives, objectives ou subjectives.


```python
# Charger un modèle Sentence Transformer pré-entraîné
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
```

    /usr/local/lib/python3.12/dist-packages/huggingface_hub/utils/_auth.py:94: UserWarning:
    
    
    The secret `HF_TOKEN` does not exist in your Colab secrets.
    To authenticate with the Hugging Face Hub, create a token in your settings tab (https://huggingface.co/settings/tokens), set it as secret in your Google Colab and restart your session.
    You will be able to reuse this secret in all of your notebooks.
    Please note that authentication is recommended but still optional to access public models or datasets.
    
    


    modules.json:   0%|          | 0.00/229 [00:00<?, ?B/s]



    config_sentence_transformers.json:   0%|          | 0.00/122 [00:00<?, ?B/s]



    README.md: 0.00B [00:00, ?B/s]



    sentence_bert_config.json:   0%|          | 0.00/53.0 [00:00<?, ?B/s]



    config.json:   0%|          | 0.00/629 [00:00<?, ?B/s]



    model.safetensors:   0%|          | 0.00/90.9M [00:00<?, ?B/s]



    Loading weights:   0%|          | 0/103 [00:00<?, ?it/s]


    BertModel LOAD REPORT from: sentence-transformers/paraphrase-MiniLM-L6-v2
    Key                     | Status     |  | 
    ------------------------+------------+--+-
    embeddings.position_ids | UNEXPECTED |  | 
    
    Notes:
    - UNEXPECTED	:can be ignored when loading from different task/architecture; not ok if you expect identical arch.
    


    tokenizer_config.json:   0%|          | 0.00/314 [00:00<?, ?B/s]



    vocab.txt: 0.00B [00:00, ?B/s]



    tokenizer.json: 0.00B [00:00, ?B/s]



    special_tokens_map.json:   0%|          | 0.00/112 [00:00<?, ?B/s]



    config.json:   0%|          | 0.00/190 [00:00<?, ?B/s]



```python
from textblob import TextBlob
# Fonction pour obtenir le sentiment d'un texte
def get_sentiment(text):
    # Créer un objet TextBlob
    blob = TextBlob(text)
    # Obtenir le sentiment
    return blob.sentiment.polarity, blob.sentiment.subjectivity

# Appliquer la fonction de sentiment à la colonne des narratives
data_reclamations['sentiment'] = data_reclamations['Consumer complaint narrative'].apply(get_sentiment)

# Créer des colonnes séparées pour la polarité et la subjectivité
data_reclamations['polarity'] = data_reclamations['sentiment'].apply(lambda x: x[0])
data_reclamations['subjectivity'] = data_reclamations['sentiment'].apply(lambda x: x[1])

# Afficher les résultats
data_reclamations[['Consumer complaint narrative', 'polarity', 'subjectivity','sentiment']].head()
```





  <div id="df-90e281ee-1c15-44e5-babb-cb0fa86de4c6" class="colab-df-container">
    <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Consumer complaint narrative</th>
      <th>polarity</th>
      <th>subjectivity</th>
      <th>sentiment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>accordance fair credit reporting act xxxx xxxx...</td>
      <td>0.171429</td>
      <td>0.633929</td>
      <td>(0.17142857142857143, 0.6339285714285714)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>believe victim fraudulent activity identity th...</td>
      <td>0.124621</td>
      <td>0.330087</td>
      <td>(0.12462121212121212, 0.3300865800865801)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>accordance fair credit reporting act list acco...</td>
      <td>0.296429</td>
      <td>0.533929</td>
      <td>(0.29642857142857143, 0.5339285714285714)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15 usc 1681 section 602 states right privacy 1...</td>
      <td>-0.004762</td>
      <td>0.545238</td>
      <td>(-0.004761904761904763, 0.5452380952380952)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>accordance fair credit reporting act xxxx xxxx...</td>
      <td>0.700000</td>
      <td>0.900000</td>
      <td>(0.7, 0.9)</td>
    </tr>
  </tbody>
</table>
</div>
    <div class="colab-df-buttons">

  <div class="colab-df-container">
    <button class="colab-df-convert" onclick="convertToInteractive('df-90e281ee-1c15-44e5-babb-cb0fa86de4c6')"
            title="Convert this dataframe to an interactive table."
            style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960">
    <path d="M120-120v-720h720v720H120Zm60-500h600v-160H180v160Zm220 220h160v-160H400v160Zm0 220h160v-160H400v160ZM180-400h160v-160H180v160Zm440 0h160v-160H620v160ZM180-180h160v-160H180v160Zm440 0h160v-160H620v160Z"/>
  </svg>
    </button>

  <style>
    .colab-df-container {
      display:flex;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    .colab-df-buttons div {
      margin-bottom: 4px;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

    <script>
      const buttonEl =
        document.querySelector('#df-90e281ee-1c15-44e5-babb-cb0fa86de4c6 button.colab-df-convert');
      buttonEl.style.display =
        google.colab.kernel.accessAllowed ? 'block' : 'none';

      async function convertToInteractive(key) {
        const element = document.querySelector('#df-90e281ee-1c15-44e5-babb-cb0fa86de4c6');
        const dataTable =
          await google.colab.kernel.invokeFunction('convertToInteractive',
                                                    [key], {});
        if (!dataTable) return;

        const docLinkHtml = 'Like what you see? Visit the ' +
          '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
          + ' to learn more about interactive tables.';
        element.innerHTML = '';
        dataTable['output_type'] = 'display_data';
        await google.colab.output.renderOutput(dataTable, element);
        const docLink = document.createElement('div');
        docLink.innerHTML = docLinkHtml;
        element.appendChild(docLink);
      }
    </script>
  </div>


    </div>
  </div>




Pour chaque réclamations, nous avons calculer le sentiment c'est à dire la calcule la polarité (positivité ou négativité) et la subjectivité (objectivité ou subjectivité) du texte en utilisant la bibliothèque TextBlob.


```python
negative_polarity = data_reclamations[data_reclamations['polarity'] < 0]
print(negative_polarity)
```

                               Consumer complaint narrative  \
    3     15 usc 1681 section 602 states right privacy 1...   
    6     xxxx xxxx im submitting complaint third party ...   
    7     contacted citibank 2 months ago regarding chec...   
    8     xx xx 2022 sent letter regarding inaccurate un...   
    9     xxxx endeavor tell victim identity theft compl...   
    ...                                                 ...   
    4989  business closed due xxxx information credit fi...   
    4992  information information relating transaction c...   
    4993  value help removed portion data credit file ca...   
    4994  ccm finance reporting negative account credit ...   
    4996  15 usc 1681 section 602 states right privacy 1...   
    
                                                      Issue  Issue_Category  \
    3                           Improper use of your report               0   
    6         Problem with fraud alerts or security freezes               2   
    7                                   Managing an account               3   
    8     Problem with a credit reporting company's inve...               4   
    9                  Incorrect information on your report               1   
    ...                                                 ...             ...   
    4989               Incorrect information on your report               1   
    4992  Problem with a credit reporting company's inve...               4   
    4993               Incorrect information on your report               1   
    4994               Incorrect information on your report               1   
    4996                        Improper use of your report               0   
    
                                             sentiment  polarity  subjectivity  
    3      (-0.004761904761904763, 0.5452380952380952) -0.004762      0.545238  
    6      (-0.06666666666666667, 0.20000000000000004) -0.066667      0.200000  
    7     (-0.0016666666666666663, 0.2672222222222222) -0.001667      0.267222  
    8       (-0.20932539682539683, 0.4220238095238095) -0.209325      0.422024  
    9                   (-0.07500000000000001, 0.1625) -0.075000      0.162500  
    ...                                            ...       ...           ...  
    4989    (-0.02799806576402322, 0.4262319241042645) -0.027998      0.426232  
    4992                  (-0.07500000000000001, 0.05) -0.075000      0.050000  
    4993    (-0.04999999999999999, 0.4000000000000001) -0.050000      0.400000  
    4994                                 (-0.18, 0.32) -0.180000      0.320000  
    4996   (-0.004761904761904763, 0.5452380952380952) -0.004762      0.545238  
    
    [1633 rows x 6 columns]
    


```python
def to_sentiment(rating):
    if rating < 0:
        return 0
    elif 0 <= rating < 0.12:
        return 1
    else:
        return 2

# Apply the to_sentiment function to the 'polarity' column
data_reclamations.loc[:, 'sentiment'] = data_reclamations.polarity.apply(to_sentiment)
class_names = ['negative', 'neutral', 'positive']

# Calculate the counts for each sentiment
sentiment_counts = data_reclamations['sentiment'].value_counts().sort_index()

# Define the colors for each sentiment
colors = ['red', 'blue', 'green']

# Create the bar chart with Plotly
fig = go.Figure(data=[
    go.Bar(
        x=class_names,
        y=sentiment_counts,
        marker_color=colors,
        text=sentiment_counts,
        textposition='auto'
    )
])

# Update layout for the plot
fig.update_layout(
    title='Distribution of Sentiments',
    xaxis_title='Sentiment',
    yaxis_title='Number of Complaints'
)

# Show the plot
fig.show()
```


<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>                <div id="99407952-4b6d-4fe1-9e42-8e741419c2ce" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("99407952-4b6d-4fe1-9e42-8e741419c2ce")) {                    Plotly.newPlot(                        "99407952-4b6d-4fe1-9e42-8e741419c2ce",                        [{"marker":{"color":["red","blue","green"]},"text":[1633.0,1710.0,1657.0],"textposition":"auto","x":["negative","neutral","positive"],"y":[1633,1710,1657],"type":"bar"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"title":{"text":"Distribution of Sentiments"},"xaxis":{"title":{"text":"Sentiment"}},"yaxis":{"title":{"text":"Number of Complaints"}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('99407952-4b6d-4fe1-9e42-8e741419c2ce');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>


Il y a :
- 1633 réclamations classées comme négatives.
- 1710 réclamations classées comme neutres.
- Il y a 1657 réclamations classées comme positives.

Ce graphique permet de visualiser la répartition des différents types de sentiments dans les réclamations des consommateurs. Les réclamations neutres sont les plus nombreuses avec 1710 occurrences.

Le fait que les réclamations neutres soient les plus nombreuses avec 1710 occurrences signifie que, parmi les réclamations analysées, la majorité n'exprime pas de sentiment fort ni positif ni négatif. Cela pourrait indiquer que de nombreux consommateurs décrivent simplement des faits ou des situations sans y ajouter de jugement émotionnel. En d'autres termes, ces réclamations se contentent de rapporter des problèmes ou des préoccupations de manière factuelle, sans exprimer une satisfaction particulière ou un mécontentement significatif.

### 3. Classification avec Bert

Nous allons maintenant passer à l'entraînement du modèle de prédiction. Nous utilisons pour cela le modèle BERT pré-entrainer à lequel nous rajoutons une couche pour la classification.

#### Tokenization et chargement du modèle

Nous commençons par préparer nos données en vue de leur utilisation avec le modèle BERT (Bidirectional Encoder Representations from Transformers). Pour cela nous allons tokenizer la description des réclamations (variable ***Consumer complaint narrative***) en utilisant la bibliothèque **transformers** de Hugging Face et **torch** de PyTorch.





```python
# Tokenizer BERT
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

# Encodage des textes
encodings = tokenizer(data_reclamations['Consumer complaint narrative'].tolist(), truncation=True, padding=True, max_length=256)

# Convertir les labels en tenseur
labels = torch.tensor(data_reclamations['Issue_Category'].tolist())

# Convertir les encodages en tenseurs
input_ids = torch.tensor(encodings['input_ids'])
attention_masks = torch.tensor(encodings['attention_mask'])
```


    tokenizer_config.json:   0%|          | 0.00/48.0 [00:00<?, ?B/s]



    vocab.txt:   0%|          | 0.00/232k [00:00<?, ?B/s]



    tokenizer.json:   0%|          | 0.00/466k [00:00<?, ?B/s]


    Warning: You are sending unauthenticated requests to the HF Hub. Please set a HF_TOKEN to enable higher rate limits and faster downloads.
    WARNING:huggingface_hub.utils._http:Warning: You are sending unauthenticated requests to the HF Hub. Please set a HF_TOKEN to enable higher rate limits and faster downloads.
    

Nous divisons ensuite notre jeu de données en données d'entraînement et de validation.


```python
# Créer un DataLoader
dataset = TensorDataset(input_ids, attention_masks, labels)

# Diviser les données en ensembles d'entraînement et de validation
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

train_dataloader = DataLoader(train_dataset, batch_size=16, shuffle=True)
val_dataloader = DataLoader(val_dataset, batch_size=16, shuffle=False)
```

Nous chargons maintenant le modèle Bert pré-entraîné pour faire de la classification de la bibliothèque **transformers** de Hugging Face. Nous définisons comme optimiseur **AdamW**, qui est une variante de l'algorithme d'optimisation Adam (elle inclut une correction pour la régularisation de type L2 : le **weight decay**) et un Scheduler (stratégie pour l'ajustement de la learning rate) de type linéaire.


```python
# Charger le modèle BERT
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=num_classes)

# Définir l'optimiseur
optimizer = AdamW(model.parameters(), lr=2e-5)

# Scheduler
total_steps = len(train_dataloader) * 3
scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=0, num_training_steps=total_steps)
```


    config.json:   0%|          | 0.00/570 [00:00<?, ?B/s]



    model.safetensors:   0%|          | 0.00/440M [00:00<?, ?B/s]



    Loading weights:   0%|          | 0/199 [00:00<?, ?it/s]


    BertForSequenceClassification LOAD REPORT from: bert-base-uncased
    Key                                        | Status     | 
    -------------------------------------------+------------+-
    cls.predictions.transform.LayerNorm.weight | UNEXPECTED | 
    cls.predictions.transform.dense.weight     | UNEXPECTED | 
    cls.seq_relationship.weight                | UNEXPECTED | 
    cls.predictions.transform.LayerNorm.bias   | UNEXPECTED | 
    cls.predictions.transform.dense.bias       | UNEXPECTED | 
    cls.seq_relationship.bias                  | UNEXPECTED | 
    cls.predictions.bias                       | UNEXPECTED | 
    classifier.weight                          | MISSING    | 
    classifier.bias                            | MISSING    | 
    
    Notes:
    - UNEXPECTED	:can be ignored when loading from different task/architecture; not ok if you expect identical arch.
    - MISSING	:those params were newly initialized because missing from the checkpoint. Consider training on your downstream task.
    


```python
# Définir l'appareil
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
model.to(device)
```




    BertForSequenceClassification(
      (bert): BertModel(
        (embeddings): BertEmbeddings(
          (word_embeddings): Embedding(30522, 768, padding_idx=0)
          (position_embeddings): Embedding(512, 768)
          (token_type_embeddings): Embedding(2, 768)
          (LayerNorm): LayerNorm((768,), eps=1e-12, elementwise_affine=True)
          (dropout): Dropout(p=0.1, inplace=False)
        )
        (encoder): BertEncoder(
          (layer): ModuleList(
            (0-11): 12 x BertLayer(
              (attention): BertAttention(
                (self): BertSelfAttention(
                  (query): Linear(in_features=768, out_features=768, bias=True)
                  (key): Linear(in_features=768, out_features=768, bias=True)
                  (value): Linear(in_features=768, out_features=768, bias=True)
                  (dropout): Dropout(p=0.1, inplace=False)
                )
                (output): BertSelfOutput(
                  (dense): Linear(in_features=768, out_features=768, bias=True)
                  (LayerNorm): LayerNorm((768,), eps=1e-12, elementwise_affine=True)
                  (dropout): Dropout(p=0.1, inplace=False)
                )
              )
              (intermediate): BertIntermediate(
                (dense): Linear(in_features=768, out_features=3072, bias=True)
                (intermediate_act_fn): GELUActivation()
              )
              (output): BertOutput(
                (dense): Linear(in_features=3072, out_features=768, bias=True)
                (LayerNorm): LayerNorm((768,), eps=1e-12, elementwise_affine=True)
                (dropout): Dropout(p=0.1, inplace=False)
              )
            )
          )
        )
        (pooler): BertPooler(
          (dense): Linear(in_features=768, out_features=768, bias=True)
          (activation): Tanh()
        )
      )
      (dropout): Dropout(p=0.1, inplace=False)
      (classifier): Linear(in_features=768, out_features=68, bias=True)
    )



#### Le modèle : entraînement et validation

Nous définissons maintenant le modèle pour l'apprentissage. Nous créons une fonction ***train_epoch*** pour la phase d'entraînement et une fonction ***eval_model*** pour la phase de validation.


```python
# Fonction d'entraînement pour une epoch
def train_epoch(model, dataloader, optimizer, device, scheduler):
    model.train()
    total_loss = 0
    for batch in dataloader:
        batch = tuple(t.to(device) for t in batch)
        inputs = {'input_ids': batch[0], 'attention_mask': batch[1], 'labels': batch[2]}
        optimizer.zero_grad()
        outputs = model(**inputs)
        loss = outputs.loss
        total_loss += loss.item()
        loss.backward()
        optimizer.step()
        scheduler.step()
    return total_loss / len(dataloader)
```


```python
# Fonction d'évaluation
def eval_model(model, dataloader, device):
    model.eval()
    predictions, true_labels = [], []
    with torch.no_grad():
        for batch in dataloader:
            batch = tuple(t.to(device) for t in batch)
            inputs = {'input_ids': batch[0], 'attention_mask': batch[1]}
            outputs = model(**inputs)
            logits = outputs.logits
            predictions.append(logits.argmax(dim=-1).cpu().numpy())
            true_labels.append(batch[2].cpu().numpy())
    predictions = np.concatenate(predictions)
    true_labels = np.concatenate(true_labels)
    return accuracy_score(true_labels, predictions), classification_report(true_labels, predictions, target_names=target_names,labels=range(num_classes), zero_division=0)

```

Nous lançons l'entraînement et l'évaluation du modèle sur 3 epochs.


```python
# Entraînement et évaluation
epochs = 3
for epoch in range(epochs):
    train_loss = train_epoch(model, train_dataloader, optimizer, device, scheduler)
    val_accuracy, val_report = eval_model(model, val_dataloader, device)
    print(f"Epoch {epoch+1}/{epochs}")
    print(f"Train loss: {train_loss}")
    print(f"Validation accuracy: {val_accuracy}")
    print(f"Validation report:\n{val_report}")
```

    Epoch 1/3
    Train loss: 2.398756009578705
    Validation accuracy: 0.458
    Validation report:
                                                                                      precision    recall  f1-score   support
    
                                                         Improper use of your report       0.51      0.91      0.65       250
                                                Incorrect information on your report       0.44      0.63      0.52       283
                                       Problem with fraud alerts or security freezes       0.00      0.00      0.00         3
                                                                 Managing an account       0.22      0.87      0.35        23
    Problem with a credit reporting company's investigation into an existing problem       0.59      0.19      0.29       180
                                                Dealing with your lender or servicer       0.00      0.00      0.00         5
                                                      Trouble during payment process       0.00      0.00      0.00        10
                                                          Managing the loan or lease       0.00      0.00      0.00         3
                                                   Attempts to collect debt not owed       0.00      0.00      0.00        46
                     Problem with a company's investigation into an existing problem       0.00      0.00      0.00        49
                                                               Getting a credit card       0.00      0.00      0.00         2
                        Problem with a lender or other company charging your account       0.00      0.00      0.00         7
                                                                Closing your account       0.00      0.00      0.00         3
                                              Problem caused by your funds being low       0.00      0.00      0.00         2
                                                                    Fees or interest       0.00      0.00      0.00         4
                                                     Written notification about debt       0.00      0.00      0.00        16
                                    Unable to get your credit report or credit score       0.00      0.00      0.00         7
                                                                       Fraud or scam       0.00      0.00      0.00         8
                                                  False statements or representation       0.00      0.00      0.00        14
                                                         Struggling to pay your loan       0.00      0.00      0.00         5
                                     Problem with a purchase shown on your statement       0.00      0.00      0.00        14
                         Applying for a mortgage or refinancing an existing mortgage       0.00      0.00      0.00         3
                                                  Other features, terms, or problems       0.00      0.00      0.00         5
                                                                        Repossession       0.00      0.00      0.00         1
                                                               Communication tactics       0.00      0.00      0.00         5
                                 Took or threatened to take negative or legal action       0.00      0.00      0.00         5
                                                             Getting a loan or lease       0.00      0.00      0.00         4
                                                           Other transaction problem       0.00      0.00      0.00         2
                            Managing, opening, or closing your mobile wallet account       0.00      0.00      0.00         1
                                                                  Closing an account       0.00      0.00      0.00         8
                                                          Struggling to pay mortgage       0.00      0.00      0.00         2
                                            Problems at the end of the loan or lease       0.00      0.00      0.00         3
                             Credit monitoring or identity theft protection services       0.00      0.00      0.00         3
                                                                  Opening an account       0.00      0.00      0.00         5
                                                             Trouble using your card       0.00      0.00      0.00         1
                             Advertising and marketing, including promotional offers       0.00      0.00      0.00         0
                                                        Problem when making payments       0.00      0.00      0.00         1
                       Problem with a company's investigation into an existing issue       0.00      0.00      0.00         1
                       Threatened to contact someone or share information improperly       0.00      0.00      0.00         2
                            Trouble accessing funds in your mobile or digital wallet       0.00      0.00      0.00         1
                                        Problem getting a card or closing an account       0.00      0.00      0.00         0
                                                         Struggling to pay your bill       0.00      0.00      0.00         1
                                                              Trouble using the card       0.00      0.00      0.00         1
                                                                Problem adding money       0.00      0.00      0.00         1
                                                               Closing on a mortgage       0.00      0.00      0.00         1
                              Problem with the payoff process at the end of the loan       0.00      0.00      0.00         0
                                       Can't stop withdrawals from your bank account       0.00      0.00      0.00         0
                                                    Can't contact lender or servicer       0.00      0.00      0.00         0
                                                 Problem with a purchase or transfer       0.00      0.00      0.00         0
                                                                    Getting the loan       0.00      0.00      0.00         1
                                                       Struggling to repay your loan       0.00      0.00      0.00         1
                                               Money was not available when promised       0.00      0.00      0.00         0
                                                           Electronic communications       0.00      0.00      0.00         0
                                                    Wrong amount charged or received       0.00      0.00      0.00         1
                                                       Problem with customer service       0.00      0.00      0.00         1
                                                               Other service problem       0.00      0.00      0.00         0
                                                    Confusing or missing disclosures       0.00      0.00      0.00         1
                                         Vehicle was repossessed or sold the vehicle       0.00      0.00      0.00         1
                              Identity theft protection or other monitoring services       0.00      0.00      0.00         1
                                          Charged fees or interest you didn't expect       0.00      0.00      0.00         1
                               Was approved for a loan, but didn't receive the money       0.00      0.00      0.00         0
                                                           Problem with cash advance       0.00      0.00      0.00         0
                                                Received a loan you didn't apply for       0.00      0.00      0.00         0
                                    Confusing or misleading advertising or marketing       0.00      0.00      0.00         1
                              Unauthorized transactions or other transaction problem       0.00      0.00      0.00         0
                                                            Unexpected or other fees       0.00      0.00      0.00         0
                                                            Getting a line of credit       0.00      0.00      0.00         0
                                                          Lost or stolen money order       0.00      0.00      0.00         0
    
                                                                            accuracy                           0.46      1000
                                                                           macro avg       0.03      0.04      0.03      1000
                                                                        weighted avg       0.36      0.46      0.37      1000
    
    Epoch 2/3
    Train loss: 1.7417294883728027
    Validation accuracy: 0.556
    Validation report:
                                                                                      precision    recall  f1-score   support
    
                                                         Improper use of your report       0.77      0.81      0.79       250
                                                Incorrect information on your report       0.56      0.73      0.63       283
                                       Problem with fraud alerts or security freezes       0.00      0.00      0.00         3
                                                                 Managing an account       0.22      0.91      0.36        23
    Problem with a credit reporting company's investigation into an existing problem       0.52      0.64      0.57       180
                                                Dealing with your lender or servicer       0.00      0.00      0.00         5
                                                      Trouble during payment process       0.00      0.00      0.00        10
                                                          Managing the loan or lease       0.00      0.00      0.00         3
                                                   Attempts to collect debt not owed       0.21      0.22      0.21        46
                     Problem with a company's investigation into an existing problem       0.00      0.00      0.00        49
                                                               Getting a credit card       0.00      0.00      0.00         2
                        Problem with a lender or other company charging your account       0.00      0.00      0.00         7
                                                                Closing your account       0.00      0.00      0.00         3
                                              Problem caused by your funds being low       0.00      0.00      0.00         2
                                                                    Fees or interest       0.00      0.00      0.00         4
                                                     Written notification about debt       0.00      0.00      0.00        16
                                    Unable to get your credit report or credit score       0.00      0.00      0.00         7
                                                                       Fraud or scam       0.00      0.00      0.00         8
                                                  False statements or representation       0.00      0.00      0.00        14
                                                         Struggling to pay your loan       0.00      0.00      0.00         5
                                     Problem with a purchase shown on your statement       0.00      0.00      0.00        14
                         Applying for a mortgage or refinancing an existing mortgage       0.00      0.00      0.00         3
                                                  Other features, terms, or problems       0.00      0.00      0.00         5
                                                                        Repossession       0.00      0.00      0.00         1
                                                               Communication tactics       0.00      0.00      0.00         5
                                 Took or threatened to take negative or legal action       0.00      0.00      0.00         5
                                                             Getting a loan or lease       0.00      0.00      0.00         4
                                                           Other transaction problem       0.00      0.00      0.00         2
                            Managing, opening, or closing your mobile wallet account       0.00      0.00      0.00         1
                                                                  Closing an account       0.00      0.00      0.00         8
                                                          Struggling to pay mortgage       0.00      0.00      0.00         2
                                            Problems at the end of the loan or lease       0.00      0.00      0.00         3
                             Credit monitoring or identity theft protection services       0.00      0.00      0.00         3
                                                                  Opening an account       0.00      0.00      0.00         5
                                                             Trouble using your card       0.00      0.00      0.00         1
                             Advertising and marketing, including promotional offers       0.00      0.00      0.00         0
                                                        Problem when making payments       0.00      0.00      0.00         1
                       Problem with a company's investigation into an existing issue       0.00      0.00      0.00         1
                       Threatened to contact someone or share information improperly       0.00      0.00      0.00         2
                            Trouble accessing funds in your mobile or digital wallet       0.00      0.00      0.00         1
                                        Problem getting a card or closing an account       0.00      0.00      0.00         0
                                                         Struggling to pay your bill       0.00      0.00      0.00         1
                                                              Trouble using the card       0.00      0.00      0.00         1
                                                                Problem adding money       0.00      0.00      0.00         1
                                                               Closing on a mortgage       0.00      0.00      0.00         1
                              Problem with the payoff process at the end of the loan       0.00      0.00      0.00         0
                                       Can't stop withdrawals from your bank account       0.00      0.00      0.00         0
                                                    Can't contact lender or servicer       0.00      0.00      0.00         0
                                                 Problem with a purchase or transfer       0.00      0.00      0.00         0
                                                                    Getting the loan       0.00      0.00      0.00         1
                                                       Struggling to repay your loan       0.00      0.00      0.00         1
                                               Money was not available when promised       0.00      0.00      0.00         0
                                                           Electronic communications       0.00      0.00      0.00         0
                                                    Wrong amount charged or received       0.00      0.00      0.00         1
                                                       Problem with customer service       0.00      0.00      0.00         1
                                                               Other service problem       0.00      0.00      0.00         0
                                                    Confusing or missing disclosures       0.00      0.00      0.00         1
                                         Vehicle was repossessed or sold the vehicle       0.00      0.00      0.00         1
                              Identity theft protection or other monitoring services       0.00      0.00      0.00         1
                                          Charged fees or interest you didn't expect       0.00      0.00      0.00         1
                               Was approved for a loan, but didn't receive the money       0.00      0.00      0.00         0
                                                           Problem with cash advance       0.00      0.00      0.00         0
                                                Received a loan you didn't apply for       0.00      0.00      0.00         0
                                    Confusing or misleading advertising or marketing       0.00      0.00      0.00         1
                              Unauthorized transactions or other transaction problem       0.00      0.00      0.00         0
                                                            Unexpected or other fees       0.00      0.00      0.00         0
                                                            Getting a line of credit       0.00      0.00      0.00         0
                                                          Lost or stolen money order       0.00      0.00      0.00         0
    
                                                                            accuracy                           0.56      1000
                                                                           macro avg       0.03      0.05      0.04      1000
                                                                        weighted avg       0.46      0.56      0.50      1000
    
    Epoch 3/3
    Train loss: 1.540094892501831
    Validation accuracy: 0.57
    Validation report:
                                                                                      precision    recall  f1-score   support
    
                                                         Improper use of your report       0.75      0.84      0.79       250
                                                Incorrect information on your report       0.64      0.69      0.67       283
                                       Problem with fraud alerts or security freezes       0.00      0.00      0.00         3
                                                                 Managing an account       0.21      0.96      0.35        23
    Problem with a credit reporting company's investigation into an existing problem       0.52      0.68      0.59       180
                                                Dealing with your lender or servicer       0.00      0.00      0.00         5
                                                      Trouble during payment process       1.00      0.20      0.33        10
                                                          Managing the loan or lease       0.00      0.00      0.00         3
                                                   Attempts to collect debt not owed       0.23      0.39      0.29        46
                     Problem with a company's investigation into an existing problem       0.00      0.00      0.00        49
                                                               Getting a credit card       0.00      0.00      0.00         2
                        Problem with a lender or other company charging your account       0.00      0.00      0.00         7
                                                                Closing your account       0.00      0.00      0.00         3
                                              Problem caused by your funds being low       0.00      0.00      0.00         2
                                                                    Fees or interest       0.00      0.00      0.00         4
                                                     Written notification about debt       0.00      0.00      0.00        16
                                    Unable to get your credit report or credit score       0.00      0.00      0.00         7
                                                                       Fraud or scam       0.00      0.00      0.00         8
                                                  False statements or representation       0.00      0.00      0.00        14
                                                         Struggling to pay your loan       0.00      0.00      0.00         5
                                     Problem with a purchase shown on your statement       0.00      0.00      0.00        14
                         Applying for a mortgage or refinancing an existing mortgage       0.00      0.00      0.00         3
                                                  Other features, terms, or problems       0.00      0.00      0.00         5
                                                                        Repossession       0.00      0.00      0.00         1
                                                               Communication tactics       0.00      0.00      0.00         5
                                 Took or threatened to take negative or legal action       0.00      0.00      0.00         5
                                                             Getting a loan or lease       0.00      0.00      0.00         4
                                                           Other transaction problem       0.00      0.00      0.00         2
                            Managing, opening, or closing your mobile wallet account       0.00      0.00      0.00         1
                                                                  Closing an account       0.00      0.00      0.00         8
                                                          Struggling to pay mortgage       0.00      0.00      0.00         2
                                            Problems at the end of the loan or lease       0.00      0.00      0.00         3
                             Credit monitoring or identity theft protection services       0.00      0.00      0.00         3
                                                                  Opening an account       0.00      0.00      0.00         5
                                                             Trouble using your card       0.00      0.00      0.00         1
                             Advertising and marketing, including promotional offers       0.00      0.00      0.00         0
                                                        Problem when making payments       0.00      0.00      0.00         1
                       Problem with a company's investigation into an existing issue       0.00      0.00      0.00         1
                       Threatened to contact someone or share information improperly       0.00      0.00      0.00         2
                            Trouble accessing funds in your mobile or digital wallet       0.00      0.00      0.00         1
                                        Problem getting a card or closing an account       0.00      0.00      0.00         0
                                                         Struggling to pay your bill       0.00      0.00      0.00         1
                                                              Trouble using the card       0.00      0.00      0.00         1
                                                                Problem adding money       0.00      0.00      0.00         1
                                                               Closing on a mortgage       0.00      0.00      0.00         1
                              Problem with the payoff process at the end of the loan       0.00      0.00      0.00         0
                                       Can't stop withdrawals from your bank account       0.00      0.00      0.00         0
                                                    Can't contact lender or servicer       0.00      0.00      0.00         0
                                                 Problem with a purchase or transfer       0.00      0.00      0.00         0
                                                                    Getting the loan       0.00      0.00      0.00         1
                                                       Struggling to repay your loan       0.00      0.00      0.00         1
                                               Money was not available when promised       0.00      0.00      0.00         0
                                                           Electronic communications       0.00      0.00      0.00         0
                                                    Wrong amount charged or received       0.00      0.00      0.00         1
                                                       Problem with customer service       0.00      0.00      0.00         1
                                                               Other service problem       0.00      0.00      0.00         0
                                                    Confusing or missing disclosures       0.00      0.00      0.00         1
                                         Vehicle was repossessed or sold the vehicle       0.00      0.00      0.00         1
                              Identity theft protection or other monitoring services       0.00      0.00      0.00         1
                                          Charged fees or interest you didn't expect       0.00      0.00      0.00         1
                               Was approved for a loan, but didn't receive the money       0.00      0.00      0.00         0
                                                           Problem with cash advance       0.00      0.00      0.00         0
                                                Received a loan you didn't apply for       0.00      0.00      0.00         0
                                    Confusing or misleading advertising or marketing       0.00      0.00      0.00         1
                              Unauthorized transactions or other transaction problem       0.00      0.00      0.00         0
                                                            Unexpected or other fees       0.00      0.00      0.00         0
                                                            Getting a line of credit       0.00      0.00      0.00         0
                                                          Lost or stolen money order       0.00      0.00      0.00         0
    
                                                                            accuracy                           0.57      1000
                                                                           macro avg       0.05      0.06      0.04      1000
                                                                        weighted avg       0.49      0.57      0.52      1000
    
    

Nous arrivons donc à 58% de précision avec notre modèle. Ce qui n'est pas vraiment optimale.

#### Prédiction du problème en fonction de la réclamation

Nous allons maintenant tester les performance de notre modèle sur une réclamation fictif.


```python
def predict_issues(model, tokenizer, texts, device):
    model.eval()
    encodings = tokenizer(texts, truncation=True, padding=True, max_length=128, return_tensors='pt')
    input_ids = encodings['input_ids'].to(device)
    attention_masks = encodings['attention_mask'].to(device)

    with torch.no_grad():
        outputs = model(input_ids, attention_mask=attention_masks)
        logits = outputs.logits
        predictions = logits.argmax(dim=-1).cpu().numpy()

    return predictions
```

Issue = Incorrect information on your report

Nous choisissons une réclamation au hasard pour tester notre modèle et nous remarquons qu'il prédit bien le problème à partir de la description de la réclamation.



```python
new_texts = ["Good day I have disputed a duplicate account with a collection company they only removed 1 account and left the other account of the same account number but everything is different. "]
predictions = predict_issues(model, tokenizer, new_texts, device)
predicted_labels = [target_names[p] for p in predictions]
print(predicted_labels)
```

    ['Incorrect information on your report']
    
